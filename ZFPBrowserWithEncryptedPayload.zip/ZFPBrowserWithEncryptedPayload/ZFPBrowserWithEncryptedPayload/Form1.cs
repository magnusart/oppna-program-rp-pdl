﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.Diagnostics;
using GEHealthcare.ZFP.Cryptography;
using GEHealthcare.ZFP.Common;
using System.Security.Cryptography;



namespace ZFPBrowserWithEncryptedPayload
{
    public partial class Form1 : Form
    {
        static string url;
        static string payload;
 
        public Form1()
        {
            InitializeComponent();
    
        }
            
        private void btnBrows_Click(object sender, EventArgs e)
        {
            //string light = "off";
            string protocol;
            if (chkSSL.Checked) { protocol = @"https://"; } else { protocol = @"http://";  };

            url = protocol + txtHostName.Text + @"/ZFP?mode=proxy&lights=off&titlebar=off#pl=";
            if (chkLights.Checked) url = url.Replace(@"lights=off",@"lights=on");
            if (chkTitlebar.Checked) url = url.Replace(@"titlebar=off", @"titlebar=on");
            
            // Replace backslash with %5C as it is not suported in url:s
            string sui = txtSUI.Text;
            if (chkEncrypt.Checked==false) sui = sui.Replace(@"\", "%5C");

            if (txtSUI.Text == "")
            {
                // Only one sui is used
                payload = @"viewall&Sui=" + txtPrimarySui.Text + @"&un=" + txtUN.Text + @"&pw=" + txtPW.Text; 
            }
            else
            {
                // one primarySui and one or many sui for comparance
                payload = @"viewall&primarySui=" + txtPrimarySui.Text + @"&sui=" + sui + @"&un=" + txtUN.Text + @"&pw=" + txtPW.Text;
            }
            //
            if (chkEncrypt.Checked)
            {
                // Initialize the cryptography parameters. Below parameters must be same as what was configured
                // in Web.config file on ZFP server for the keys "PrivateKey", "CipherMode" and "PaddingMode".
                
                // Create an instance of CryptographyConfiguration class.
                ICryptographyConfiguration _cryptographyConfiguration = new CryptographyConfiguration(txtPrivateKey.Text, txtCipherMode.Text, txtPaddingMode.Text);

                //Create an instance of CryptographyService class.
                ICryptographyService _cryptographyService = new CryptographyService(_cryptographyConfiguration);

                byte[] iv = new byte[]{0,0,0,0,0,0,0,0};

                PasswordDeriveBytes slask = new PasswordDeriveBytes(txtPrivateKey.Text, null);
                byte[] svar =   slask.CryptDeriveKey("TripleDES", "SHA1", 192, iv);

                string hex = BitConverter.ToString(svar).Replace("-","");
                txtEncryptionKey.Text = hex;
                    
                // Call CryptographyService.Encrypt method to get encrypted payload. This will append UTC timestamp 
                // (yyyyMMddHHmmss) to the original string to be encrypted and then performs encryption.
                payload = _cryptographyService.Encrypt(payload);
            }
            url += payload;
            txtUrl.Text = url;

            if (chkBrows.Checked)
            {
                Process proc = new Process();
                proc.StartInfo.FileName = url;
                proc.StartInfo.UseShellExecute = true;
                proc.Start();
            }

        }

        private void label1_Click(object sender, EventArgs e)
        {

        }

        private void lblTimeStamp_Click(object sender, EventArgs e)
        {

        }

        private void Form1_Load(object sender, EventArgs e)
        {

        }

        private void radioButton1_CheckedChanged(object sender, EventArgs e)
        {

        }

        private void radioButton2_CheckedChanged(object sender, EventArgs e)
        {

        }

        private void chkBrows_CheckedChanged(object sender, EventArgs e)
        {
            if (chkBrows.Checked) 
            {
                btnBrows.Text = "Brows";
            }
            else 
            {
                btnBrows.Text = "Generate url";
            }

        }

        private void label1_Click_1(object sender, EventArgs e)
        {

        }

        private void textBox1_TextChanged(object sender, EventArgs e)
        {

        }

        private void txtPW_TextChanged(object sender, EventArgs e)
        {

        }
    }
}