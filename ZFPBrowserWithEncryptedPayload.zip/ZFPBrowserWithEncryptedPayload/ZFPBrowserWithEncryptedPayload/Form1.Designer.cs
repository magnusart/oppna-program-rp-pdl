﻿namespace ZFPBrowserWithEncryptedPayload
{
    partial class Form1
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.btnBrows = new System.Windows.Forms.Button();
            this.lblURL = new System.Windows.Forms.Label();
            this.txtUrl = new System.Windows.Forms.TextBox();
            this.txtPW = new System.Windows.Forms.TextBox();
            this.lblPW = new System.Windows.Forms.Label();
            this.lblUN = new System.Windows.Forms.Label();
            this.txtUN = new System.Windows.Forms.TextBox();
            this.lblPrimarySui = new System.Windows.Forms.Label();
            this.txtPrimarySui = new System.Windows.Forms.TextBox();
            this.lblSUI = new System.Windows.Forms.Label();
            this.txtSUI = new System.Windows.Forms.TextBox();
            this.lblPrivateKey = new System.Windows.Forms.Label();
            this.txtPrivateKey = new System.Windows.Forms.TextBox();
            this.chkLights = new System.Windows.Forms.CheckBox();
            this.chkTitlebar = new System.Windows.Forms.CheckBox();
            this.lblHostName = new System.Windows.Forms.Label();
            this.txtHostName = new System.Windows.Forms.TextBox();
            this.chkEncrypt = new System.Windows.Forms.CheckBox();
            this.lblCipherMode = new System.Windows.Forms.Label();
            this.txtCipherMode = new System.Windows.Forms.TextBox();
            this.lblpaddingMode = new System.Windows.Forms.Label();
            this.txtPaddingMode = new System.Windows.Forms.TextBox();
            this.chkBrows = new System.Windows.Forms.CheckBox();
            this.chkSSL = new System.Windows.Forms.CheckBox();
            this.txtEncryptionKey = new System.Windows.Forms.TextBox();
            this.lblEncryptionKey = new System.Windows.Forms.Label();
            this.SuspendLayout();
            // 
            // btnBrows
            // 
            this.btnBrows.Location = new System.Drawing.Point(1084, 99);
            this.btnBrows.Name = "btnBrows";
            this.btnBrows.Size = new System.Drawing.Size(100, 23);
            this.btnBrows.TabIndex = 1;
            this.btnBrows.Text = "Brows";
            this.btnBrows.UseVisualStyleBackColor = true;
            this.btnBrows.Click += new System.EventHandler(this.btnBrows_Click);
            // 
            // lblURL
            // 
            this.lblURL.AutoSize = true;
            this.lblURL.Location = new System.Drawing.Point(38, 14);
            this.lblURL.Name = "lblURL";
            this.lblURL.Size = new System.Drawing.Size(21, 13);
            this.lblURL.TabIndex = 2;
            this.lblURL.Text = "url:";
            this.lblURL.Click += new System.EventHandler(this.label1_Click);
            // 
            // txtUrl
            // 
            this.txtUrl.Location = new System.Drawing.Point(65, 7);
            this.txtUrl.Name = "txtUrl";
            this.txtUrl.Size = new System.Drawing.Size(1119, 20);
            this.txtUrl.TabIndex = 0;
            // 
            // txtPW
            // 
            this.txtPW.Location = new System.Drawing.Point(205, 85);
            this.txtPW.Name = "txtPW";
            this.txtPW.Size = new System.Drawing.Size(100, 20);
            this.txtPW.TabIndex = 3;
            this.txtPW.TextChanged += new System.EventHandler(this.txtPW_TextChanged);
            // 
            // lblPW
            // 
            this.lblPW.AutoSize = true;
            this.lblPW.Location = new System.Drawing.Point(173, 92);
            this.lblPW.Name = "lblPW";
            this.lblPW.Size = new System.Drawing.Size(27, 13);
            this.lblPW.TabIndex = 4;
            this.lblPW.Text = "pw=";
            // 
            // lblUN
            // 
            this.lblUN.AutoSize = true;
            this.lblUN.Location = new System.Drawing.Point(36, 92);
            this.lblUN.Name = "lblUN";
            this.lblUN.Size = new System.Drawing.Size(25, 13);
            this.lblUN.TabIndex = 6;
            this.lblUN.Text = "un=";
            // 
            // txtUN
            // 
            this.txtUN.Location = new System.Drawing.Point(67, 85);
            this.txtUN.Name = "txtUN";
            this.txtUN.Size = new System.Drawing.Size(100, 20);
            this.txtUN.TabIndex = 5;
            this.txtUN.Text = "ZFPViewer";
            // 
            // lblPrimarySui
            // 
            this.lblPrimarySui.AutoSize = true;
            this.lblPrimarySui.Location = new System.Drawing.Point(2, 40);
            this.lblPrimarySui.Name = "lblPrimarySui";
            this.lblPrimarySui.Size = new System.Drawing.Size(61, 13);
            this.lblPrimarySui.TabIndex = 10;
            this.lblPrimarySui.Text = "primarySui=";
            // 
            // txtPrimarySui
            // 
            this.txtPrimarySui.Location = new System.Drawing.Point(65, 33);
            this.txtPrimarySui.Name = "txtPrimarySui";
            this.txtPrimarySui.Size = new System.Drawing.Size(338, 20);
            this.txtPrimarySui.TabIndex = 9;
            this.txtPrimarySui.Text = "1.2.840.113619.2.327.3.3918146098.186.1405661233.252";
            // 
            // lblSUI
            // 
            this.lblSUI.AutoSize = true;
            this.lblSUI.Location = new System.Drawing.Point(36, 66);
            this.lblSUI.Name = "lblSUI";
            this.lblSUI.Size = new System.Drawing.Size(26, 13);
            this.lblSUI.TabIndex = 8;
            this.lblSUI.Text = "sui=";
            // 
            // txtSUI
            // 
            this.txtSUI.Location = new System.Drawing.Point(65, 59);
            this.txtSUI.Name = "txtSUI";
            this.txtSUI.Size = new System.Drawing.Size(1119, 20);
            this.txtSUI.TabIndex = 7;
            this.txtSUI.Text = "1.2.752.24.5.375546860.20131119214228.2995042\\1.2.840.113619.2.284.3.3918143282.2" +
    "53.1351141786.974";
            // 
            // lblPrivateKey
            // 
            this.lblPrivateKey.AutoSize = true;
            this.lblPrivateKey.Location = new System.Drawing.Point(311, 92);
            this.lblPrivateKey.Name = "lblPrivateKey";
            this.lblPrivateKey.Size = new System.Drawing.Size(64, 13);
            this.lblPrivateKey.TabIndex = 14;
            this.lblPrivateKey.Text = "PrivateKey=";
            // 
            // txtPrivateKey
            // 
            this.txtPrivateKey.Location = new System.Drawing.Point(381, 85);
            this.txtPrivateKey.Name = "txtPrivateKey";
            this.txtPrivateKey.Size = new System.Drawing.Size(127, 20);
            this.txtPrivateKey.TabIndex = 13;
            // 
            // chkLights
            // 
            this.chkLights.AutoSize = true;
            this.chkLights.Location = new System.Drawing.Point(65, 117);
            this.chkLights.Name = "chkLights";
            this.chkLights.Size = new System.Drawing.Size(54, 17);
            this.chkLights.TabIndex = 15;
            this.chkLights.Text = "Lights";
            this.chkLights.UseVisualStyleBackColor = true;
            // 
            // chkTitlebar
            // 
            this.chkTitlebar.AutoSize = true;
            this.chkTitlebar.Location = new System.Drawing.Point(125, 117);
            this.chkTitlebar.Name = "chkTitlebar";
            this.chkTitlebar.Size = new System.Drawing.Size(61, 17);
            this.chkTitlebar.TabIndex = 16;
            this.chkTitlebar.Text = "Titlebar";
            this.chkTitlebar.UseVisualStyleBackColor = true;
            // 
            // lblHostName
            // 
            this.lblHostName.AutoSize = true;
            this.lblHostName.Location = new System.Drawing.Point(612, 124);
            this.lblHostName.Name = "lblHostName";
            this.lblHostName.Size = new System.Drawing.Size(63, 13);
            this.lblHostName.TabIndex = 18;
            this.lblHostName.Text = "HostName=";
            // 
            // txtHostName
            // 
            this.txtHostName.Location = new System.Drawing.Point(682, 117);
            this.txtHostName.Name = "txtHostName";
            this.txtHostName.Size = new System.Drawing.Size(127, 20);
            this.txtHostName.TabIndex = 17;
            // 
            // chkEncrypt
            // 
            this.chkEncrypt.AutoSize = true;
            this.chkEncrypt.Checked = true;
            this.chkEncrypt.CheckState = System.Windows.Forms.CheckState.Checked;
            this.chkEncrypt.Location = new System.Drawing.Point(192, 117);
            this.chkEncrypt.Name = "chkEncrypt";
            this.chkEncrypt.Size = new System.Drawing.Size(62, 17);
            this.chkEncrypt.TabIndex = 19;
            this.chkEncrypt.Text = "Encrypt";
            this.chkEncrypt.UseVisualStyleBackColor = true;
            // 
            // lblCipherMode
            // 
            this.lblCipherMode.AutoSize = true;
            this.lblCipherMode.Location = new System.Drawing.Point(311, 118);
            this.lblCipherMode.Name = "lblCipherMode";
            this.lblCipherMode.Size = new System.Drawing.Size(69, 13);
            this.lblCipherMode.TabIndex = 21;
            this.lblCipherMode.Text = "cipherMode=";
            // 
            // txtCipherMode
            // 
            this.txtCipherMode.Location = new System.Drawing.Point(381, 111);
            this.txtCipherMode.Name = "txtCipherMode";
            this.txtCipherMode.Size = new System.Drawing.Size(61, 20);
            this.txtCipherMode.TabIndex = 20;
            this.txtCipherMode.Text = "ECB";
            // 
            // lblpaddingMode
            // 
            this.lblpaddingMode.AutoSize = true;
            this.lblpaddingMode.Location = new System.Drawing.Point(448, 118);
            this.lblpaddingMode.Name = "lblpaddingMode";
            this.lblpaddingMode.Size = new System.Drawing.Size(78, 13);
            this.lblpaddingMode.TabIndex = 23;
            this.lblpaddingMode.Text = "paddingMode=";
            // 
            // txtPaddingMode
            // 
            this.txtPaddingMode.Location = new System.Drawing.Point(532, 111);
            this.txtPaddingMode.Name = "txtPaddingMode";
            this.txtPaddingMode.Size = new System.Drawing.Size(61, 20);
            this.txtPaddingMode.TabIndex = 22;
            this.txtPaddingMode.Text = "PKCS7";
            // 
            // chkBrows
            // 
            this.chkBrows.AutoSize = true;
            this.chkBrows.Checked = true;
            this.chkBrows.CheckState = System.Windows.Forms.CheckState.Checked;
            this.chkBrows.Location = new System.Drawing.Point(972, 105);
            this.chkBrows.Name = "chkBrows";
            this.chkBrows.Size = new System.Drawing.Size(55, 17);
            this.chkBrows.TabIndex = 24;
            this.chkBrows.Text = "Brows";
            this.chkBrows.UseVisualStyleBackColor = true;
            this.chkBrows.CheckedChanged += new System.EventHandler(this.chkBrows_CheckedChanged);
            // 
            // chkSSL
            // 
            this.chkSSL.AutoSize = true;
            this.chkSSL.Checked = true;
            this.chkSSL.CheckState = System.Windows.Forms.CheckState.Checked;
            this.chkSSL.Location = new System.Drawing.Point(260, 118);
            this.chkSSL.Name = "chkSSL";
            this.chkSSL.Size = new System.Drawing.Size(38, 17);
            this.chkSSL.TabIndex = 25;
            this.chkSSL.Text = "ssl";
            this.chkSSL.UseVisualStyleBackColor = true;
            // 
            // txtEncryptionKey
            // 
            this.txtEncryptionKey.Location = new System.Drawing.Point(599, 89);
            this.txtEncryptionKey.Name = "txtEncryptionKey";
            this.txtEncryptionKey.Size = new System.Drawing.Size(357, 20);
            this.txtEncryptionKey.TabIndex = 26;
            this.txtEncryptionKey.TextChanged += new System.EventHandler(this.textBox1_TextChanged);
            // 
            // lblEncryptionKey
            // 
            this.lblEncryptionKey.AutoSize = true;
            this.lblEncryptionKey.Location = new System.Drawing.Point(512, 95);
            this.lblEncryptionKey.Name = "lblEncryptionKey";
            this.lblEncryptionKey.Size = new System.Drawing.Size(81, 13);
            this.lblEncryptionKey.TabIndex = 27;
            this.lblEncryptionKey.Text = "EncryptionKey=";
            this.lblEncryptionKey.Click += new System.EventHandler(this.label1_Click_1);
            // 
            // Form1
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(1199, 146);
            this.Controls.Add(this.lblEncryptionKey);
            this.Controls.Add(this.txtEncryptionKey);
            this.Controls.Add(this.chkSSL);
            this.Controls.Add(this.chkBrows);
            this.Controls.Add(this.lblpaddingMode);
            this.Controls.Add(this.txtPaddingMode);
            this.Controls.Add(this.lblCipherMode);
            this.Controls.Add(this.txtCipherMode);
            this.Controls.Add(this.chkEncrypt);
            this.Controls.Add(this.lblHostName);
            this.Controls.Add(this.txtHostName);
            this.Controls.Add(this.chkTitlebar);
            this.Controls.Add(this.chkLights);
            this.Controls.Add(this.lblPrivateKey);
            this.Controls.Add(this.txtPrivateKey);
            this.Controls.Add(this.lblPrimarySui);
            this.Controls.Add(this.txtPrimarySui);
            this.Controls.Add(this.lblSUI);
            this.Controls.Add(this.txtSUI);
            this.Controls.Add(this.lblUN);
            this.Controls.Add(this.txtUN);
            this.Controls.Add(this.lblPW);
            this.Controls.Add(this.txtPW);
            this.Controls.Add(this.lblURL);
            this.Controls.Add(this.btnBrows);
            this.Controls.Add(this.txtUrl);
            this.Name = "Form1";
            this.Text = "ZFP url launcher";
            this.Load += new System.EventHandler(this.Form1_Load);
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Button btnBrows;
        private System.Windows.Forms.Label lblURL;
        private System.Windows.Forms.TextBox txtUrl;
        private System.Windows.Forms.TextBox txtPW;
        private System.Windows.Forms.Label lblPW;
        private System.Windows.Forms.Label lblUN;
        private System.Windows.Forms.TextBox txtUN;
        private System.Windows.Forms.Label lblPrimarySui;
        private System.Windows.Forms.TextBox txtPrimarySui;
        private System.Windows.Forms.Label lblSUI;
        private System.Windows.Forms.TextBox txtSUI;
        private System.Windows.Forms.Label lblPrivateKey;
        private System.Windows.Forms.TextBox txtPrivateKey;
        private System.Windows.Forms.CheckBox chkLights;
        private System.Windows.Forms.CheckBox chkTitlebar;
        private System.Windows.Forms.Label lblHostName;
        private System.Windows.Forms.TextBox txtHostName;
        private System.Windows.Forms.CheckBox chkEncrypt;
        private System.Windows.Forms.Label lblCipherMode;
        private System.Windows.Forms.TextBox txtCipherMode;
        private System.Windows.Forms.Label lblpaddingMode;
        private System.Windows.Forms.TextBox txtPaddingMode;
        private System.Windows.Forms.CheckBox chkBrows;
        private System.Windows.Forms.CheckBox chkSSL;
        private System.Windows.Forms.TextBox txtEncryptionKey;
        private System.Windows.Forms.Label lblEncryptionKey;
    }
}

